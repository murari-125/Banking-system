## Banking System
* C++ console application <br>
* Contains basic banking facilities <br>
* Built using the concept of OOP in C++ <br>
* Stores data locally <br>
* Compile app.cpp file to generate executable file and run the program <br>

